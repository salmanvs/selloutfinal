package addStadium_dummy;

public class Stadium {
	private int id;
	private String add_stadium_stadium_name,add_stadium_location,add_stadium_total_seat_count,add_stadium_silver_seat_count,add_stadium_gold_seat_count,add_stadium_platinum_seat_count;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAdd_stadium_stadium_name() {
		return add_stadium_stadium_name;
	}
	public void setAdd_stadium_stadium_name(String add_stadium_stadium_name) {
		this.add_stadium_stadium_name = add_stadium_stadium_name;
	}
	public String getAdd_stadium_location() {
		return add_stadium_location;
	}
	public void setAdd_stadium_location(String add_stadium_location) {
		this.add_stadium_location = add_stadium_location;
	}
	public String getAdd_stadium_total_seat_count() {
		return add_stadium_total_seat_count;
	}
	public void setAdd_stadium_total_seat_count(String add_stadium_total_seat_count) {
		this.add_stadium_total_seat_count = add_stadium_total_seat_count;
	}
	public String getAdd_stadium_silver_seat_count() {
		return add_stadium_silver_seat_count;
	}
	public void setAdd_stadium_silver_seat_count(String add_stadium_silver_seat_count) {
		this.add_stadium_silver_seat_count = add_stadium_silver_seat_count;
	}
	public String getAdd_stadium_gold_seat_count() {
		return add_stadium_gold_seat_count;
	}
	public void setAdd_stadium_gold_seat_count(String add_stadium_gold_seat_count) {
		this.add_stadium_gold_seat_count = add_stadium_gold_seat_count;
	}
	public String getAdd_stadium_platinum_seat_count() {
		return add_stadium_platinum_seat_count;
	}
	public void setAdd_stadium_platinum_seat_count(String add_stadium_platinum_seat_count) {
		this.add_stadium_platinum_seat_count = add_stadium_platinum_seat_count;
	}
	
}	