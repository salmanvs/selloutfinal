package viewprofile;

import java.sql.Connection;
import java.sql.DriverManager;

import databaseConnection.*;

public class ViewprofileDao {
	
	public static Connection getConnection() {

		Connection con = null;
		try {
			Class.forName(Databaseconnection.driverClass);
			con = DriverManager.getConnection(Databaseconnection.connectionUrl,Databaseconnection.username,Databaseconnection.password);
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;

}

}
