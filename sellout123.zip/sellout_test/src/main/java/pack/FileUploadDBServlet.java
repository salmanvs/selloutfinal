package pack;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import databaseConnection.Databaseconnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.websocket.Session;

@WebServlet("/uploadServlet")
@MultipartConfig(maxFileSize = 16177215) // upload file's size up to 16MB
public class FileUploadDBServlet extends HttpServlet {

	/*
	 * // database connection settings private String dbURL =
	 * "jdbc:mysql://192.168.18.245:3306/javadbtest"; private String dbUser =
	 * "javadbtest"; private String dbPass = "GFW5sdwfxt";
	 */

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// gets values of text fields
		/*
		 * String firstName = request.getParameter("firstName"); String lastName =
		 * request.getParameter("lastName");
		 */

		InputStream inputStream = null; // input stream of the upload file
		String email=request.getParameter("eemail");

		// obtains the upload file part in this multipart request
		Part filePart = request.getPart("photo");
		if (filePart != null) {
			// prints out some information for debugging
			System.out.println(filePart.getName());
			System.out.println(filePart.getSize());
			System.out.println(filePart.getContentType());

			// obtains input stream of the upload file
			inputStream = filePart.getInputStream();
		}

		Connection conn = null; // connection to the database
		String message = null; // message will be sent back to client

		try {
			// connects to the database
			Class.forName("com.mysql.jdbc.Driver");

			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sellout", Databaseconnection.username,
					Databaseconnection.password);

			// constructs SQL statement
			String sql = "update user_details set user_details_add_profile_picture=? where user_details_email=?";
			PreparedStatement statement = conn.prepareStatement(sql);

			if (inputStream != null) {
				// fetches input stream of the upload file for the blob column
				statement.setBlob(1, inputStream);
				statement.setString(2, email); 
			}

			// sends the statement to the database server
			int row = statement.executeUpdate();
			if (row > 0) {
				/* message = "File uploaded and saved into database"; */
				request.getRequestDispatcher("success_upload.jsp").include(request, response);
			}
		} catch (Exception ex) {
			message = "ERROR: " + ex.getMessage();
			ex.printStackTrace();
		} finally {
			if (conn != null) {
				// closes the database connection
				try {
					conn.close();
				} catch (SQLException ex) {
					ex.printStackTrace();
				}
			}
			// sets the message in request scope
			request.setAttribute("Message", message);

			// forwards to the message page
			getServletContext().getRequestDispatcher("success_upload.jsp").forward(request, response);
		}
	}
}