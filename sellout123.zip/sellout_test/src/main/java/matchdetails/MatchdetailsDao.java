package matchdetails;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import addStadium_dummy.Stadium;
import matchdetails.Matchdetails;
import profile_dummy.User_profile;
import databaseConnection.Databaseconnection;

public class MatchdetailsDao {

	public static Connection getConnection() {

		Connection con = null;
		try {
			Class.forName(Databaseconnection.driverClass);
			con = DriverManager.getConnection(Databaseconnection.connectionUrl, Databaseconnection.username,
					Databaseconnection.password);
		} catch (Exception e) {
			System.out.println(e);
		}

		return con;

	}

	public static int save(Matchdetails u) {
		int status = 0;
		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement(
					"insert into match_details(match_details_match_name,match_details_stadium_name,match_details_match_date,match_details_match_time,match_details_match_discription,match_details_total_seat_count,match_details_silver_seat_count,match_details_gold_seat_count,match_details_platinum_seat_count,match_details_silver_seat_price,match_details_gold_seat_price,match_details_platinum_seat_price) values(?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, u.getMatch_details_match_name());
			ps.setString(2, u.getMatch_details_stadium_name());
			ps.setString(3, u.getMatch_details_match_date());
			ps.setString(4, u.getMatch_details_match_time());
			ps.setString(5, u.getMatch_details_match_discription());
			ps.setString(6, u.getMatch_details_total_seat_count());
			ps.setString(7, u.getMatch_details_silver_seat_count());
			ps.setString(8, u.getMatch_details_gold_seat_count());
			ps.setString(9, u.getMatch_details_platinum_seat_count());
			ps.setString(10, u.getMatch_details_silver_seat_price());
			ps.setString(11, u.getMatch_details_gold_seat_price());
			ps.setString(12, u.getMatch_details_platinum_seat_price());
			status = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return status;
	}

	public static List<Matchdetails> getRecordByStadiumName(String stadiumname) {
		List<Matchdetails> list = new ArrayList<Matchdetails>();
		try {
			Connection con = getConnection();
			PreparedStatement ps = con
					.prepareStatement("select * from match_details where match_details_stadium_name=?");
			ps.setString(1, stadiumname);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Matchdetails u = new Matchdetails();
				u.setId(rs.getInt(1));
				u.setMatch_details_match_name(rs.getString(2));
				u.setMatch_details_stadium_name(rs.getString(3));
				u.setMatch_details_match_date(rs.getString(4));
				u.setMatch_details_match_time(rs.getString(5));
				u.setMatch_details_match_discription(rs.getString(6));
				u.setMatch_details_total_seat_count(rs.getString(7));
				u.setMatch_details_silver_seat_count(rs.getString(8));
				u.setMatch_details_gold_seat_count(rs.getString(9));
				u.setMatch_details_platinum_seat_count(rs.getString(10));
				u.setMatch_details_silver_seat_price(rs.getString(11));
				u.setMatch_details_gold_seat_price(rs.getString(12));
				u.setMatch_details_platinum_seat_price(rs.getString(13));
				list.add(u);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}

	public static List<Matchdetails> getAllRecordss() {
		List<Matchdetails> list = new ArrayList<Matchdetails>();

		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement("select * from match_details");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Matchdetails u = new Matchdetails();
				u.setId(rs.getInt(1));
				u.setMatch_details_match_name(rs.getString(2));
				u.setMatch_details_stadium_name(rs.getString(3));
				u.setMatch_details_match_date(rs.getString(4));
				u.setMatch_details_match_time(rs.getString(5));
				u.setMatch_details_match_discription(rs.getString(6));
				u.setMatch_details_total_seat_count(rs.getString(7));
				u.setMatch_details_silver_seat_count(rs.getString(8));
				u.setMatch_details_gold_seat_count(rs.getString(9));
				u.setMatch_details_platinum_seat_count(rs.getString(10));
				u.setMatch_details_silver_seat_price(rs.getString(11));
				u.setMatch_details_gold_seat_price(rs.getString(12));
				u.setMatch_details_platinum_seat_price(rs.getString(13));

				list.add(u);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}

	public static List<Matchdetails> getAllRecords() {
		List<Matchdetails> list = new ArrayList<Matchdetails>();

		try {
			Connection con = getConnection();
			PreparedStatement ps = con
					.prepareStatement("select * from match_details where match_details_stadium_name=?");
			ps.setString(1, "Jawaharlal Nehru Stadium");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Matchdetails u = new Matchdetails();
				u.setId(rs.getInt(1));
				u.setMatch_details_match_name(rs.getString(2));
				u.setMatch_details_stadium_name(rs.getString(3));
				u.setMatch_details_match_date(rs.getString(4));
				u.setMatch_details_match_time(rs.getString(5));
				u.setMatch_details_match_discription(rs.getString(6));
				u.setMatch_details_total_seat_count(rs.getString(7));
				u.setMatch_details_silver_seat_count(rs.getString(8));
				u.setMatch_details_gold_seat_count(rs.getString(9));
				u.setMatch_details_platinum_seat_count(rs.getString(10));
				u.setMatch_details_silver_seat_price(rs.getString(11));
				u.setMatch_details_gold_seat_price(rs.getString(12));
				u.setMatch_details_platinum_seat_price(rs.getString(13));

				list.add(u);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}

	public static int delete(Matchdetails u) {
		int status = 0;
		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement("delete from match_details where match_details_id=?");
			ps.setInt(1, u.getId());
			status = ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}

		return status;
	}

	public static List<Matchdetails> getAllRecordz() {
		List<Matchdetails> list = new ArrayList<Matchdetails>();

		try {
			Connection con = getConnection();
			PreparedStatement ps = con.prepareStatement("select * from match_details");
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Matchdetails u = new Matchdetails();
				u.setId(rs.getInt("match_details_id"));
				u.setMatch_details_match_name(rs.getString("match_details_match_name"));
				u.setMatch_details_stadium_name(rs.getString("match_details_stadium_name"));
				u.setMatch_details_match_date(rs.getString(4));
				u.setMatch_details_match_time(rs.getString(5));
				u.setMatch_details_match_discription(rs.getString(6));
				u.setMatch_details_total_seat_count(rs.getString(7));
				u.setMatch_details_silver_seat_count(rs.getString("match_details_silver_seat_count"));
				u.setMatch_details_gold_seat_count(rs.getString("match_details_gold_seat_count"));
				u.setMatch_details_platinum_seat_count(rs.getString("match_details_platinum_seat_count"));
				u.setMatch_details_silver_seat_price(rs.getString("match_details_silver_seat_price"));
				u.setMatch_details_gold_seat_price(rs.getString("match_details_gold_seat_price"));
				u.setMatch_details_platinum_seat_price(rs.getString("match_details_platinum_seat_price"));

				list.add(u);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}

}
