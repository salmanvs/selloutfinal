package profile;

public class Profile {
	private int id;
	private String user_details_name,user_details_mobile_number,user_details_place,user_details_email,user_details_country,user_details_state;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getUser_details_mobile_number() {
		return user_details_mobile_number;
	}
	public void setUser_details_mobile_number(String user_details_mobile_number) {
		this.user_details_mobile_number = user_details_mobile_number;
	}
	public String getUser_details_name() {
		return user_details_name;
	}
	public void setUser_details_name(String user_details_name) {
		this.user_details_name = user_details_name;
	}
	public String getUser_details_place() {
		return user_details_place;
	}
	public void setUser_details_place(String user_details_place) {
		this.user_details_place = user_details_place;
	}
	public String getUser_details_email() {
		return user_details_email;
	}
	public void setUser_details_email(String user_details_email) {
		this.user_details_email = user_details_email;
	}
	public String getUser_details_country() {
		return user_details_country;
	}
	public void setUser_details_country(String user_details_country) {
		this.user_details_country = user_details_country;
	}
	public String getUser_details_state() {
		return user_details_state;
	}
	public void setUser_details_state(String user_details_state) {
		this.user_details_state = user_details_state;
	}

}
