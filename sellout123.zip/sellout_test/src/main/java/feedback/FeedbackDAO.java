package feedback;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import databaseConnection.*;


public class FeedbackDAO {
	public static Connection getConnection() {

		Connection con = null;
		try {
			Class.forName(Databaseconnection.driverClass);
			con = DriverManager.getConnection(Databaseconnection.connectionUrl,Databaseconnection.username,Databaseconnection.password);
		} catch (Exception e) {
			System.out.println(e);
		}
	
		return con;

}

public static int save(Feedback u) {
	int status = 0;
	try {
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("insert into feedback(feedback_user_feedback) values(?)");
		ps.setString(1,u.getFeedback_user_feedback());
		
		status = ps.executeUpdate();
	} catch (Exception e) {
		System.out.println(e);
	}
	return status;
}

public static List<Feedback> getAllRecords() {
	List<Feedback> list = new ArrayList<Feedback>();

	try {
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("select * from feedback");
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			Feedback u = new Feedback();
			u.setId(rs.getInt("feedback_id"));
			u.setFeedback_user_feedback(rs.getString(2));
			list.add(u);
		}
	} catch (Exception e) {
		System.out.println(e);
	}
	return list;
}

}
